let workouts = JSON.parse(localStorage.getItem('fitlifeWorkouts') || '[]');
let workoutDates = JSON.parse(localStorage.getItem('fitlifeWorkoutDates') || '[]');

const goalPerWeek = 4;

function saveWorkoutDate() {
  const today = new Date().toISOString().split('T')[0];
  workoutDates.push(today);
  localStorage.setItem('fitlifeWorkoutDates', JSON.stringify(workoutDates));
}

document.addEventListener('init', function (event) {
  const page = event.target;

  if (page.id === 'workouts') {
    renderWorkouts();
  }

  if (page.id === 'addWorkoutPage') {
    setTimeout(() => {
      renderExerciseFields();
    }, 100);
  }

  if (page.id === 'workoutDetailPage') {
    const workoutIndex = page.data.index;
    showWorkoutDetails(workoutIndex);
  }

  if (page.id === 'progress') {
    updateProgressView();
  }

  if (page.id === 'dashboard') {
    
  }
});

function openAddWorkout() {
  document.querySelector('#appNavigator').pushPage('add-workout.html');
}

function addExercise() {
  const exerciseList = document.getElementById('exerciseList');

  const container = document.createElement('ons-list-item');
  container.innerHTML = `
    <div class="exercise-row">
      <ons-input class="exercise-name" placeholder="Exercise" float></ons-input>
      <ons-input class="exercise-sets" type="number" placeholder="Sets" float></ons-input>
      <ons-input class="exercise-reps" type="number" placeholder="Reps" float></ons-input>
    </div>
  `;

  exerciseList.appendChild(container);
}

function renderExerciseFields() {
  const exerciseList = document.getElementById('exerciseList');
  exerciseList.innerHTML = '';
  addExercise();
}

function saveWorkout() {
  const name = document.getElementById('workoutName').value.trim();
  const exerciseNames = document.querySelectorAll('.exercise-name');
  const exerciseReps = document.querySelectorAll('.exercise-reps');
  const exerciseSets = document.querySelectorAll('.exercise-sets');

  const exercises = [];

  for (let i = 0; i < exerciseNames.length; i++) {
    const ename = exerciseNames[i].value.trim();
    const ereps = parseInt(exerciseReps[i].value || 0);
    const esets = parseInt(exerciseSets[i].value || 0);
    if (ename) {
      exercises.push({ name: ename, reps: ereps, sets: esets });
    }
  }

  if (!name || exercises.length === 0) {
    if (navigator.notification && navigator.notification.alert) {
      navigator.notification.alert(
        'You must enter a workout name and at least one exercise to continue.',
        null,
        '⚠️ Required Fields Missing',
        'OK'
      );
    } else {
      alert('You must enter a workout name and at least one exercise to continue.');
    }
    return;
  }

  workouts.push({ name, exercises });
  localStorage.setItem('fitlifeWorkouts', JSON.stringify(workouts));
  saveWorkoutDate();

  if (navigator.vibrate) {
    navigator.vibrate(200);
  }

  ons.notification.toast('Workout saved!', { timeout: 1000 });
  document.querySelector('#appNavigator').popPage().then(() => {
    renderWorkouts();
  });
}

function renderWorkouts() {
  const list = document.getElementById('workoutList');
  if (!list) return;

  list.innerHTML = '';

  if (workouts.length === 0) {
    list.innerHTML = '<ons-list-item>No workouts yet.</ons-list-item>';
    return;
  }

  workouts.forEach((w, i) => {
    const item = document.createElement('ons-list-item');
    item.setAttribute('modifier', 'longdivider');

    item.innerHTML = `
      <div class="center">
        ${w.name}
      </div>
      <div class="right">
        <ons-icon icon="fa-trash" style="color: red; margin-left: 10px;" onclick="deleteWorkout(${i})"></ons-icon>
      </div>
    `;
    item.onclick = (e) => {
      if (!e.target.closest('ons-icon')) {
        document.querySelector('#appNavigator').pushPage('workout-detail.html', {
          data: { index: i }
        });
      }
    };
    list.appendChild(item);
  });
}

function deleteWorkout(index) {
  if (navigator.notification && navigator.notification.confirm) {
    navigator.notification.confirm(
      'Are you sure you want to delete this workout?',
      function(buttonIndex) {
        if (buttonIndex === 1) {
          workouts.splice(index, 1);
          localStorage.setItem('fitlifeWorkouts', JSON.stringify(workouts));
          renderWorkouts();
        }
      },
      'Delete Workout',
      ['Yes', 'Cancel']
    );
  } else {
    if (confirm('Are you sure you want to delete this workout?')) {
      workouts.splice(index, 1);
      localStorage.setItem('fitlifeWorkouts', JSON.stringify(workouts));
      renderWorkouts();
    }
  }
}

function showWorkoutDetails(index) {
  const workout = workouts[index];
  document.getElementById('detailTitle').textContent = workout.name;

  const list = document.getElementById('detailExerciseList');
  list.innerHTML = '';

  workout.exercises.forEach(ex => {
    let detail = `${ex.name}`;
    if (ex.sets && ex.reps) {
      detail += ` – ${ex.sets} sets x ${ex.reps} reps`;
    } else if (ex.sets) {
      detail += ` – ${ex.sets} sets`;
    } else if (ex.reps) {
      detail += ` – ${ex.reps} reps`;
    }

    const item = document.createElement('ons-list-item');
    item.innerHTML = detail;
    list.appendChild(item);
  });
}

function logWorkout() {
  let count = parseInt(localStorage.getItem('workoutCount') || '0');
  count++;
  localStorage.setItem('workoutCount', count);
  saveWorkoutDate();
  ons.notification.toast(`Workout logged! Total: ${count}`, { timeout: 2000 });
  updateProgressView();
}

function updateProgressView() {
  let count = parseInt(localStorage.getItem('workoutCount') || '0');
  const content = document.getElementById('progressContent');
  if (content) {
    let summary = `<p>✅ You have logged <strong>${count}</strong> workout(s) so far!</p>`;
    const thisWeek = getWorkoutCountThisWeek();
    summary += `<p>📅 This week: <strong>${thisWeek}/${goalPerWeek}</strong> workouts</p>`;
    const streak = getCurrentStreak();
    summary += `<p>🔥 Current streak: <strong>${streak}</strong> day(s)</p>`;

    const historyList = workoutDates
      .slice()
      .reverse()
      .map(date => `<div>✅ ${date}</div>`) 
      .join('');

    summary += `<div>${historyList}</div>`;
    content.innerHTML = summary;
    renderWeeklyWorkoutChart();
  }
}

function renderWeeklyWorkoutChart() {
  const ctx = document.getElementById('weeklyChart');
  if (!ctx) return;

  if (window.weeklyChartInstance) {
    window.weeklyChartInstance.destroy();
  }

  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const data = new Array(7).fill(0);
  const today = new Date();
  const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));

  workoutDates.forEach(dateStr => {
    const d = new Date(dateStr);
    if (d >= startOfWeek) {
      const dayIndex = d.getDay();
      data[dayIndex]++;
    }
  });

  window.weeklyChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: days,
      datasets: [{
        label: 'Workouts This Week',
        data: data,
        backgroundColor: '#6a1b9a'
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          ticks: { stepSize: 1 }
        }
      }
    }
  });
}

function getWorkoutCountThisWeek() {
  const now = new Date();
  const currentWeekStart = new Date(now.setDate(now.getDate() - now.getDay()));
  return workoutDates.filter(dateStr => {
    const d = new Date(dateStr);
    return d >= currentWeekStart;
  }).length;
}

function getCurrentStreak() {
  const sorted = [...new Set(workoutDates)].sort().reverse();
  let streak = 0;
  let day = new Date();

  for (let i = 0; i < sorted.length; i++) {
    const d = new Date(sorted[i]);
    if (d.toDateString() === day.toDateString()) {
      streak++;
      day.setDate(day.getDate() - 1);
    } else {
      break;
    }
  }
  return streak;
}

function findNearbyGym() {
  const infoBox = document.getElementById('locationInfo');
  if (!navigator.geolocation) {
    infoBox.innerText = 'Geolocation not supported.';
    return;
  }

  navigator.geolocation.getCurrentPosition(
    function (position) {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;

      infoBox.innerHTML = `
        🌍 Your coordinates:<br>
        Latitude: ${lat.toFixed(4)}<br>
        Longitude: ${lng.toFixed(4)}<br>
      `;

      const googleMapsUrl = `https://www.google.com/maps/search/gym/@${lat},${lng},15z`;

      const openBtn = document.createElement('ons-button');
      openBtn.textContent = 'Open in Google Maps';
      openBtn.style.marginTop = '10px';
      openBtn.onclick = () => window.open(googleMapsUrl, '_system');
      infoBox.appendChild(openBtn);
    },
    function (error) {
      infoBox.innerText = 'Error getting location: ' + error.message;
    },
    {
      enableHighAccuracy: true,
      timeout: 5000
    }
  );
}